// cPanel / Phusion Passenger Node.js Application Startup File
const fs = require('fs');
const path = require('path');

const logFile = path.join(__dirname, 'debug.log');

function debugLog(msg) {
  try {
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(logFile, line);
  } catch (_e) {}
}

debugLog('🚀 Starting Node.js App from app.js...');

try {
  require('./dist/server.js');
  debugLog('✅ Successfully loaded dist/server.js');
} catch (err) {
  debugLog('❌ CRITICAL ERROR loading dist/server.js: ' + (err.stack || err.message || err));
  console.error('CRITICAL ERROR loading dist/server.js:', err);
  throw err;
}
